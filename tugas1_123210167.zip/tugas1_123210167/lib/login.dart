import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Login Page"),
        ),
        body: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
                child: Image.network(
                  "https://2.bp.blogspot.com/-HIikE_BpasQ/V-hZ6_ykoXI/AAAAAAAAEks/skwrS575BQMkQVRna_7vRxlFTo7rv0hKgCLcB/s1600/Logo%2BUpn%2BVeteran%2BYogyakarta%2B1.png",
                  height: 200, // Atur tinggi gambar menjadi 200 piksel
                  width: 200,  // Atur lebar gambar menjadi 200 piksel
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: TextField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(90.0),
                    ),
                    labelText: 'Username',
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(90.0),
                    ),
                    labelText: 'Password',
                  ),
                ),
              ),
              Container(
                  height: 80,
                  padding: const EdgeInsets.all(20),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                    ),
                    child: const Text('Login'),
                    onPressed: () {
                      print("halo");
                      //Navigator.pushReplacement(context,
                        //MaterialPageRoute(builder: (context) => BottomNavigation()),
                     // );
                    },
                  )),
            ],
          ),
        ));
  }
}