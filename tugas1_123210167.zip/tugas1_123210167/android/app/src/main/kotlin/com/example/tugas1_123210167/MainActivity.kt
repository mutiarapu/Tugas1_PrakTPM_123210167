package com.example.tugas1_123210167

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
